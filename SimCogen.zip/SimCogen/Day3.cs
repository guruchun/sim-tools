﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimCogen
{
    public partial class Day3 : Form
    {
        public Day3()
        {
            InitializeComponent();
        }

        private void Day3_Load(object sender, EventArgs e)
        {

        }
    }
}

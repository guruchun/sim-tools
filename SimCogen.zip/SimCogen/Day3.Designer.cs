﻿namespace SimCogen
{
    partial class Day3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Day3));
            this.PicFan3 = new System.Windows.Forms.PictureBox();
            this.PicFan2 = new System.Windows.Forms.PictureBox();
            this.PicFan1 = new System.Windows.Forms.PictureBox();
            this.PicPmp01 = new System.Windows.Forms.PictureBox();
            this.PicPmp02 = new System.Windows.Forms.PictureBox();
            this.PicNc412 = new System.Windows.Forms.PictureBox();
            this.PicNc413 = new System.Windows.Forms.PictureBox();
            this.PicNc417 = new System.Windows.Forms.PictureBox();
            this.DgvFC = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TankLevel = new System.Windows.Forms.Button();
            this.TxtPit03 = new System.Windows.Forms.TextBox();
            this.TxtTtTh6 = new System.Windows.Forms.TextBox();
            this.TxtThH = new System.Windows.Forms.TextBox();
            this.TxtThL = new System.Windows.Forms.TextBox();
            this.TxtThM = new System.Windows.Forms.TextBox();
            this.TxtPit01 = new System.Windows.Forms.TextBox();
            this.TxtTtTh3 = new System.Windows.Forms.TextBox();
            this.TxtPit02 = new System.Windows.Forms.TextBox();
            this.TxtFwVer = new System.Windows.Forms.TextBox();
            this.FcID = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CogenBG = new System.Windows.Forms.PictureBox();
            this.DgvCogen = new System.Windows.Forms.DataGridView();
            this.CogName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CogValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CogDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.PicFan3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicFan2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicFan1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicPmp01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicPmp02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicNc412)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicNc413)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicNc417)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvFC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CogenBG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvCogen)).BeginInit();
            this.SuspendLayout();
            // 
            // PicFan3
            // 
            this.PicFan3.BackColor = System.Drawing.Color.Transparent;
            this.PicFan3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicFan3.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicFan3.InitialImage = global::SimCogen.Properties.Resources.dot_gray;
            this.PicFan3.Location = new System.Drawing.Point(336, 561);
            this.PicFan3.Name = "PicFan3";
            this.PicFan3.Size = new System.Drawing.Size(17, 16);
            this.PicFan3.TabIndex = 49;
            this.PicFan3.TabStop = false;
            this.PicFan3.Click += new System.EventHandler(this.Pic_Click);
            // 
            // PicFan2
            // 
            this.PicFan2.BackColor = System.Drawing.Color.Transparent;
            this.PicFan2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicFan2.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicFan2.Location = new System.Drawing.Point(336, 546);
            this.PicFan2.Name = "PicFan2";
            this.PicFan2.Size = new System.Drawing.Size(17, 16);
            this.PicFan2.TabIndex = 51;
            this.PicFan2.TabStop = false;
            this.PicFan2.Click += new System.EventHandler(this.Pic_Click);
            // 
            // PicFan1
            // 
            this.PicFan1.BackColor = System.Drawing.Color.Transparent;
            this.PicFan1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicFan1.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicFan1.Location = new System.Drawing.Point(336, 531);
            this.PicFan1.Name = "PicFan1";
            this.PicFan1.Size = new System.Drawing.Size(17, 16);
            this.PicFan1.TabIndex = 50;
            this.PicFan1.TabStop = false;
            this.PicFan1.Click += new System.EventHandler(this.Pic_Click);
            // 
            // PicPmp01
            // 
            this.PicPmp01.BackColor = System.Drawing.Color.Transparent;
            this.PicPmp01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicPmp01.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicPmp01.InitialImage = global::SimCogen.Properties.Resources.dot_gray;
            this.PicPmp01.Location = new System.Drawing.Point(659, 361);
            this.PicPmp01.Name = "PicPmp01";
            this.PicPmp01.Size = new System.Drawing.Size(17, 16);
            this.PicPmp01.TabIndex = 42;
            this.PicPmp01.TabStop = false;
            this.PicPmp01.Click += new System.EventHandler(this.Pic_Click);
            // 
            // PicPmp02
            // 
            this.PicPmp02.BackColor = System.Drawing.Color.Transparent;
            this.PicPmp02.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicPmp02.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicPmp02.Location = new System.Drawing.Point(410, 451);
            this.PicPmp02.Name = "PicPmp02";
            this.PicPmp02.Size = new System.Drawing.Size(17, 16);
            this.PicPmp02.TabIndex = 41;
            this.PicPmp02.TabStop = false;
            this.PicPmp02.Click += new System.EventHandler(this.Pic_Click);
            // 
            // PicNc412
            // 
            this.PicNc412.BackColor = System.Drawing.Color.Transparent;
            this.PicNc412.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicNc412.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicNc412.Location = new System.Drawing.Point(582, 463);
            this.PicNc412.Name = "PicNc412";
            this.PicNc412.Size = new System.Drawing.Size(17, 16);
            this.PicNc412.TabIndex = 40;
            this.PicNc412.TabStop = false;
            this.PicNc412.Click += new System.EventHandler(this.Pic_Click);
            // 
            // PicNc413
            // 
            this.PicNc413.BackColor = System.Drawing.Color.Transparent;
            this.PicNc413.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicNc413.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicNc413.Location = new System.Drawing.Point(579, 160);
            this.PicNc413.Name = "PicNc413";
            this.PicNc413.Size = new System.Drawing.Size(17, 16);
            this.PicNc413.TabIndex = 43;
            this.PicNc413.TabStop = false;
            this.PicNc413.Click += new System.EventHandler(this.Pic_Click);
            // 
            // PicNc417
            // 
            this.PicNc417.BackColor = System.Drawing.Color.Transparent;
            this.PicNc417.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PicNc417.Image = global::SimCogen.Properties.Resources.dot_red;
            this.PicNc417.Location = new System.Drawing.Point(580, 113);
            this.PicNc417.Name = "PicNc417";
            this.PicNc417.Size = new System.Drawing.Size(17, 16);
            this.PicNc417.TabIndex = 39;
            this.PicNc417.TabStop = false;
            this.PicNc417.Click += new System.EventHandler(this.Pic_Click);
            // 
            // DgvFC
            // 
            this.DgvFC.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DgvFC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvFC.Location = new System.Drawing.Point(890, 362);
            this.DgvFC.Name = "DgvFC";
            this.DgvFC.RowHeadersVisible = false;
            this.DgvFC.RowTemplate.Height = 25;
            this.DgvFC.Size = new System.Drawing.Size(202, 243);
            this.DgvFC.TabIndex = 47;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1011, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 15);
            this.label5.TabIndex = 46;
            this.label5.Text = "ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(887, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 15);
            this.label2.TabIndex = 45;
            this.label2.Text = "Cogen 상태 설정";
            // 
            // TankLevel
            // 
            this.TankLevel.BackColor = System.Drawing.Color.Blue;
            this.TankLevel.FlatAppearance.BorderSize = 0;
            this.TankLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TankLevel.Font = new System.Drawing.Font("맑은 고딕", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TankLevel.ForeColor = System.Drawing.Color.LightGray;
            this.TankLevel.Location = new System.Drawing.Point(417, 226);
            this.TankLevel.Name = "TankLevel";
            this.TankLevel.Size = new System.Drawing.Size(145, 188);
            this.TankLevel.TabIndex = 44;
            this.TankLevel.Text = "축열조";
            this.TankLevel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.TankLevel.UseVisualStyleBackColor = false;
            // 
            // TxtPit03
            // 
            this.TxtPit03.Location = new System.Drawing.Point(791, 360);
            this.TxtPit03.Name = "TxtPit03";
            this.TxtPit03.Size = new System.Drawing.Size(56, 23);
            this.TxtPit03.TabIndex = 37;
            this.TxtPit03.Tag = "PIT-02";
            // 
            // TxtTtTh6
            // 
            this.TxtTtTh6.Location = new System.Drawing.Point(791, 220);
            this.TxtTtTh6.Name = "TxtTtTh6";
            this.TxtTtTh6.Size = new System.Drawing.Size(56, 23);
            this.TxtTtTh6.TabIndex = 38;
            // 
            // TxtThH
            // 
            this.TxtThH.Location = new System.Drawing.Point(568, 238);
            this.TxtThH.Name = "TxtThH";
            this.TxtThH.Size = new System.Drawing.Size(56, 23);
            this.TxtThH.TabIndex = 36;
            // 
            // TxtThL
            // 
            this.TxtThL.Location = new System.Drawing.Point(568, 395);
            this.TxtThL.Name = "TxtThL";
            this.TxtThL.Size = new System.Drawing.Size(56, 23);
            this.TxtThL.TabIndex = 35;
            // 
            // TxtThM
            // 
            this.TxtThM.Location = new System.Drawing.Point(568, 316);
            this.TxtThM.Name = "TxtThM";
            this.TxtThM.Size = new System.Drawing.Size(56, 23);
            this.TxtThM.TabIndex = 34;
            // 
            // TxtPit01
            // 
            this.TxtPit01.Location = new System.Drawing.Point(454, 479);
            this.TxtPit01.Name = "TxtPit01";
            this.TxtPit01.Size = new System.Drawing.Size(56, 23);
            this.TxtPit01.TabIndex = 33;
            // 
            // TxtTtTh3
            // 
            this.TxtTtTh3.Location = new System.Drawing.Point(454, 436);
            this.TxtTtTh3.Name = "TxtTtTh3";
            this.TxtTtTh3.Size = new System.Drawing.Size(56, 23);
            this.TxtTtTh3.TabIndex = 30;
            // 
            // TxtPit02
            // 
            this.TxtPit02.Location = new System.Drawing.Point(227, 443);
            this.TxtPit02.Name = "TxtPit02";
            this.TxtPit02.Size = new System.Drawing.Size(56, 23);
            this.TxtPit02.TabIndex = 31;
            // 
            // TxtFwVer
            // 
            this.TxtFwVer.Location = new System.Drawing.Point(110, 88);
            this.TxtFwVer.Name = "TxtFwVer";
            this.TxtFwVer.Size = new System.Drawing.Size(100, 23);
            this.TxtFwVer.TabIndex = 32;
            this.TxtFwVer.Text = "fdsfads";
            this.TxtFwVer.TextChanged += new System.EventHandler(this.Txt_TextChanged);
            // 
            // FcID
            // 
            this.FcID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FcID.FormattingEnabled = true;
            this.FcID.Location = new System.Drawing.Point(1036, 334);
            this.FcID.Name = "FcID";
            this.FcID.Size = new System.Drawing.Size(56, 23);
            this.FcID.TabIndex = 28;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(886, 337);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 15);
            this.label3.TabIndex = 27;
            this.label3.Text = "연료전지 조회";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 15);
            this.label1.TabIndex = 26;
            this.label1.Text = "Cogen 상태";
            // 
            // CogenBG
            // 
            this.CogenBG.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CogenBG.BackgroundImage")));
            this.CogenBG.Location = new System.Drawing.Point(87, 61);
            this.CogenBG.Name = "CogenBG";
            this.CogenBG.Size = new System.Drawing.Size(773, 544);
            this.CogenBG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CogenBG.TabIndex = 29;
            this.CogenBG.TabStop = false;
            // 
            // DgvCogen
            // 
            this.DgvCogen.AllowUserToAddRows = false;
            this.DgvCogen.AllowUserToDeleteRows = false;
            this.DgvCogen.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DgvCogen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvCogen.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CogName,
            this.CogValue,
            this.CogDesc});
            this.DgvCogen.Location = new System.Drawing.Point(887, 61);
            this.DgvCogen.Name = "DgvCogen";
            this.DgvCogen.RowHeadersVisible = false;
            this.DgvCogen.RowTemplate.Height = 25;
            this.DgvCogen.Size = new System.Drawing.Size(205, 248);
            this.DgvCogen.TabIndex = 52;
            // 
            // CogName
            // 
            this.CogName.HeaderText = "Column1";
            this.CogName.Name = "CogName";
            // 
            // CogValue
            // 
            this.CogValue.HeaderText = "Column2";
            this.CogValue.Name = "CogValue";
            // 
            // CogDesc
            // 
            this.CogDesc.HeaderText = "Column3";
            this.CogDesc.Name = "CogDesc";
            // 
            // Day3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1179, 645);
            this.Controls.Add(this.DgvCogen);
            this.Controls.Add(this.PicFan3);
            this.Controls.Add(this.PicFan2);
            this.Controls.Add(this.PicFan1);
            this.Controls.Add(this.PicPmp01);
            this.Controls.Add(this.PicPmp02);
            this.Controls.Add(this.PicNc412);
            this.Controls.Add(this.PicNc413);
            this.Controls.Add(this.PicNc417);
            this.Controls.Add(this.DgvFC);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TankLevel);
            this.Controls.Add(this.TxtPit03);
            this.Controls.Add(this.TxtTtTh6);
            this.Controls.Add(this.TxtThH);
            this.Controls.Add(this.TxtThL);
            this.Controls.Add(this.TxtThM);
            this.Controls.Add(this.TxtPit01);
            this.Controls.Add(this.TxtTtTh3);
            this.Controls.Add(this.TxtPit02);
            this.Controls.Add(this.TxtFwVer);
            this.Controls.Add(this.FcID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CogenBG);
            this.Name = "Day3";
            this.Text = "Day3";
            this.Load += new System.EventHandler(this.Day3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicFan3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicFan2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicFan1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicPmp01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicPmp02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicNc412)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicNc413)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicNc417)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvFC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CogenBG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgvCogen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox PicFan3;
        private PictureBox PicFan2;
        private PictureBox PicFan1;
        private PictureBox PicPmp01;
        private PictureBox PicPmp02;
        private PictureBox PicNc412;
        private PictureBox PicNc413;
        private PictureBox PicNc417;
        private DataGridView DgvFC;
        private Label label5;
        private Label label2;
        private Button TankLevel;
        private TextBox TxtPit03;
        private TextBox TxtTtTh6;
        private TextBox TxtThH;
        private TextBox TxtThL;
        private TextBox TxtThM;
        private TextBox TxtPit01;
        private TextBox TxtTtTh3;
        private TextBox TxtPit02;
        private TextBox TxtFwVer;
        private ComboBox FcID;
        private Label label3;
        private Label label1;
        private PictureBox CogenBG;
        private DataGridView DgvCogen;
        private DataGridViewTextBoxColumn CogName;
        private DataGridViewTextBoxColumn CogValue;
        private DataGridViewTextBoxColumn CogDesc;
    }
}